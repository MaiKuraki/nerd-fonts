
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit c09f4c09b97bce8978c4c3104c4bbb5b7549228b
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Thu Nov 21 14:38:48 2024 +0100
        
            Update readme's font-patcher version
            
            No options changed, but it just looks better to have a more recent
            version number in the example.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
