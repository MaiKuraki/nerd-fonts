
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit a4ddd1e867936e1ba76047ad8da65918af48933f
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue Jun 11 22:35:23 2024 +0200
        
            Fix Gohufont 14 question mark
            
            Also clean up README situation.
            
            Fixes: #1652
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
