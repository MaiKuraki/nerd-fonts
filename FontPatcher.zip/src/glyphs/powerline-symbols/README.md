# Powerline Symbols

For more information have a look at the upstream website: https://github.com/powerline/powerline

## Source modified

* Glyph 0xE0B0 and 0xE0B2 got an additional 7% strip on their straight side.

Version: 1.000 (from about 2013)
