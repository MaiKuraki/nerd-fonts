# Vorillaz' Devicons

Here are some very few icons from the Devicons project before it got forked.
They got dropped when Devicons had been forked. But we find them basic enough
to be important and there are no direct substitudes in other sets.

Most icons that were dropped on the Devicons for are now also dropped here:

For more information have a look at the upstream websites:
* https://github.com/vorillaz/devicons
* https://github.com/devicon/devicons

This is taken directly from the repository default branch, which is ahead of release 1.8.0.
We call it 1.8.1 here, but there is no such release.

Version: 1.8.1
